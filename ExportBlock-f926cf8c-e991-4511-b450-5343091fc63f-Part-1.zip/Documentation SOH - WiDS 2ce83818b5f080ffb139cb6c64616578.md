# Documentation SOH - WiDS

Week 1

[Introduction to the Project and History of SOH ](Documentation%20SOH%20-%20WiDS/Introduction%20to%20the%20Project%20and%20History%20of%20SOH%202d983818b5f080a283f6cecddfaba95c.md)

[PINNs - Physics Informed Neural Networks](Documentation%20SOH%20-%20WiDS/PINNs%20-%20Physics%20Informed%20Neural%20Networks%202d983818b5f0808faddae4b13e079b84.md)

[Deeper Introduction to PINNs](Documentation%20SOH%20-%20WiDS/Deeper%20Introduction%20to%20PINNs%202d983818b5f080b9aa7bd80cb8502f12.md)

Week 2

[Introduction to Batteries](Documentation%20SOH%20-%20WiDS/Introduction%20to%20Batteries%202e083818b5f08003a0a6c30d0109d114.md)

[Running a PyBaMM simulation for Battery Experiment - Pending do in Week 3](Documentation%20SOH%20-%20WiDS/Running%20a%20PyBaMM%20simulation%20for%20Battery%20Experiment%202e083818b5f0806093bbd5d08ada307a.md)

[How to model batteries](Documentation%20SOH%20-%20WiDS/How%20to%20model%20batteries%202e183818b5f080e497d2fd681a60b4de.md)