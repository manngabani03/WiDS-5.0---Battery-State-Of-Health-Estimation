# Introduction to the Project and History of SOH

Main Research Paper

https://www.sciencedirect.com/science/article/pii/S0360544224006005?via%3Dihub

Introduction to the Project and SOH

Lithium Ion Batteries are key for acheiving a sustainable society becuase of reasons such as high energy density, high specific enery, low pollution and low energy consumption making it clean energy solutions. Lithium Ion Batteries are also regareded as ‘White Gold’ in the 21st century.

However due to thier variable internal electrochemical properties, the degradtion of LIBs is highly intricate,severe LIBs’ failures may lead to extremely adverse consequences and signifi
cant pecuniary losses

Therefore prognostics and health management of these batteries is very crucial for safety and relaiblity, thus leading to BMS (Battery Management systems)

State monitoring is a basic function of BMS, includees State of Charge, State of Energy and State of Power. SOH of LIBs reflects the deterioration in performance during chargeand discharge cycles and is one of the key state parameters.

Current Methods that estimate LIBs SOH -  two categoreis

1. PBMs Physics Based Models
2. Data-driven Approach DDA
3. PIML - Mix of both worls

PBM - Pseudo-two-dimensional model(P2D) - DFN Model - **old-standard physics-based model** for **lithium-ion batteries**, widely used in **optimization, safety, degradation, and SOH-related studies**.

Governing Eqns of P2D

It is **not fully 3D**, but captures the **two most important dimensions**:

1. **x-direction (through-thickness of the cell)**
    - Negative electrode → Separator → Positive electrode
2. **r-direction (inside spherical active material particles)**
    - Lithium diffusion inside solid particles

👉 Hence: **1D (x) + 1D (r) = Pseudo-2D**

Xu et al. - described batteries dynamics using an equivalent circuit model, applying recursive least squares for online parameter identification, using unscented Kalman Filter to estimate battery state, and associated SOH with capacity fade caused by irreversible lithium losses.

Problems with using PBMs are they demand for a high and clean quality dataset, along with certain conditions to be fulfilled, and thus are very sensitive to noise during measurement process, also PBMs require more complex models and computational resources, making less ideal for practical and industrial applications

Thus we have started with DDA, it is precisely because establishing data-driven models does not require understanding the aging mechanisms of LIBs, and data-driven models often involve dimensionality reduction and feature engineering [23], that the predictions of data-driven models may violate physical principles, making them unrealistic and unreasonable

Thus PIML - Physics Informed Machine Learning is the best we got

One of the examples is 

Singh et al. [26] predicted the charging state and state health of LIBs by incorporating the partial differential equations of Fick’s diffusion law from a single-particle model into the training process of a neural network

The P-IC (Peak Incremental Capacity) having different peaks, widhts and positions, indicate the electrochemical reactions that occur during the deg of LIBs, Decrease in P-IC is directly prop to loss of active materials in LIBs.If peak height decreases then loss of active material, peak broadening then increased polarization/resistance.

With the increase in the charging and discharging cycles, active materials continuosuly degrade as they are unable to accomodate lithium. The degradation of active materials is one of the primary reasons for the degradation of LIBs.

Thus using this monotonic relation of P-IC and SOH, along with physics constrained FNN (Feedforward Neural networks) to imporve prediction accuracy, and performance of model validated on the NASA datasets from kaggle,