# Introduction to Batteries

How do lithium batteries work?

Lithium is the lightest of all metals, has the greatest electrochemical potential and provides the largest specific energy per weight. Rechargeable batteries with lithium metal on the anode could provide extraordinarily high energy densities. In the mid-1980s it was found that cycling produced unwanted dendrites on the anode, these growth particles penetrate the separator and cause and electrical short, thus the cell temperature would rise quickly and approach the melting point of lithium, causing a thermal runaway, known as ‘venting with flame’. Thus the creation of Li-ion batteries, although lower in specific energy than lithium-metal, this was safe provided the current and voltage limits were respected.

Li-ion is a low-maintenance battery, an advantage that most other chemistries cannot claim. The battery has no memory and does not need exercising to keep it in good shape. Self-discharge is less than half that of nickel-based systems and this helps the fuel gauge applications. 

The nominal cell voltage of 3.60V can directly power mobile phones, tablets and digital cameras, offering simplifications and cost reductions over multi-cell designs. The only drawbacks are the need for protection circuits to prevent abuse, as well as high price.

What is inside these Lithium-ion Batteries 

Lithium-ion uses a cathode (positive electrode), an anode (negative electrode) and electrolyte as conductor. The cathode is metal oxide and the anode consists of porous carbon. During discharge, the ions flow from the anode to the cathode through the electrolyte and separator; charge reverses the direction and the ions flow from the cathode to the anode.

C-Rates

Charge and Discharging rates of batteries are goverened by c-rates

The capacity of a battery is commonly rated at 1C, meaning that a fully charged battery rated at 1Ah should provide 1A for one hour.The same battery discharging at 0.5C should provide 500mA for two hours, and at 2C it delivers 2A for 30 minutes

How to measure this capacity is by using an analyzer which discharges the battery at a calibrated current while measuring the time until the end-of-discharge voltage is reached. So if the battery is 1C, then after 30 mins the analyzer will show 50%

When discharging a battery with a battery analyzer capable of applying different C rates, a higher C rate will produce a lower capacity reading and vice versa. This is very easy to understand as it is essentially a 1Ah battery if used at 2C rate will be able to provide for 30mins only

In reality, internal losses turn some of the energy into heat and lower the resulting capacity to about 95 percent or less. Discharging the same battery at 0.5C, or 500mA over 2 hours, will likely increase the capacity to above 100 percent.

![image.png](Introduction%20to%20Batteries/image.png)

The image just shows how lead-acid batteries, or nickel-based or Li-ion based batteries are able to provide the C-rates and their discharge time

How to prolong Lithium based Batteries

Li-ion batteries are charged to three different SoC levels and the cycle life modelled. Limiting the charge range prolongs battery life but decreases energy delivered. This reflects in increased weight and higher initial cost

The cycle count on DST (dynamic stress test) differs with battery type, charge time, loading protocol and operating temperature

Environmental conditions also govern the longevity of lithium-ion batteries. The worst situation is keeping a fully charges battery at elevated temperatures, as battery packs do not die suddenly, but the runtime gradually shortens as the capacity fades.

Lower charge voltages prolong battery life and electric vehicles and satellites take advantage of this fact

We have the Long-Life/Conservation mode Battery options in laptop which limits the battery charged to 80% which lowers the charge voltage the laptop is connected to the AC grid, along with this a cool laptop also extends battery life, because as we said the operating and environmental conditions also affect battery life.

How to model the batteries