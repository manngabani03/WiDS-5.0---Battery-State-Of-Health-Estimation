# Deeper Introduction to PINNs

Starting with Physics informed Machine Learning

What are we moelling 

What data will inform the model - labels, source

Architecture - Any NN, Model

Crafting loss fn

Employ optimization algo - some epoch like gradient descent, ADAM - hyperparameter tuning, using langrage multipliers, contrainsed least square

Zoo of NNs

![image.png](Deeper%20Introduction%20to%20PINNs/image.png)

If your system has some invariane or symmetry, people just use it make a bigger dataset

Inductive Bias - Using physics early helping in the downstream

The Digital Twin 

PINNs

PINNs Loss Function

![image.png](Deeper%20Introduction%20to%20PINNs/image%201.png)

These loss functions are usually something which is zero, eg Divergence of vector field being zero

There can be something known as lambda, which is the like managing both the data and virtual as they will constantly be fighting over each other 

![image.png](Deeper%20Introduction%20to%20PINNs/image%202.png)

Difference between PINNs and Naive NN

fPINNs - Fractional PINNs when you have both PDE as well ODE, having powers in integrals or differentials and thus you divide into two categories

![image.png](Deeper%20Introduction%20to%20PINNs/image%203.png)

Start the lambda with zero and slowly increase to optimal 

How to implement PINNs in Python

1. DXDE recc but pytorch can be used
2. If you have a ODE well and good, just use Loss ODE = 0, if there are residuals they are the loss, same way also take the boundary condiitions as loss, and square them up
3. tf.GradientTape is used for automatic Derivate
4. tensorflow is used neural network building
5. Building a Neural Network
    
    ![image.png](Deeper%20Introduction%20to%20PINNs/image%204.png)
    
6. Building the PDE loss and Boundary condition loss functions
    
    ![image.png](Deeper%20Introduction%20to%20PINNs/image%205.png)
    
    ![image.png](Deeper%20Introduction%20to%20PINNs/image%206.png)
    
7.