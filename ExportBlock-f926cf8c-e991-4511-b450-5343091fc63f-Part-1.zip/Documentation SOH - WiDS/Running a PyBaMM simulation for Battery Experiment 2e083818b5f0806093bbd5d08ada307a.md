# Running a PyBaMM simulation for Battery Experiment - Pending do in Week 3

%pip install pybamm - Calling PyBaMM inside the code cell